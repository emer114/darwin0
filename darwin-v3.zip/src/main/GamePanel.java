package main;

import darwin1.player;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class GamePanel extends JPanel implements Runnable {

    // Screen Settings
    final int originalTileSize = 16;
    final int scale            = 3;
    public final int tileSize  = originalTileSize * scale; // 48px

    final int maxScreenCol = 16;
    final int maxScreenRow = 12;
    public final int screenWidth  = tileSize * maxScreenCol; // 768px
    public final int screenHeight = tileSize * maxScreenRow; // 576px

    // Floor height (how thick ang ground)
    public final int floorHeight = 48;

    // World width (50 tiles long)
    public final int worldWidth = tileSize * 50;

    // Camera
    int cameraX = 0;

    // FPS
    int fps = 60;

    // Game State
    GameState gameState = GameState.MAIN_MENU;

    // Key & Player
    KeyHandler keyH = new KeyHandler();
    player player1;

    Thread gameThread;

    // Tile image (optional - loads if file exists)
    BufferedImage groundTile = null;

    public GamePanel() {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(new Color(135, 206, 235)); // sky blue
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);

        player1 = new player(this, keyH);

        // Try loading ground tile
        try {
            groundTile = ImageIO.read(getClass().getResourceAsStream("/res/tiles/ground.png"));
        } catch (Exception e) {
            groundTile = null;
        }
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000.0 / fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (gameThread != null) {
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if (delta >= 1) {
                update();
                repaint();
                delta--;
                drawCount++;
            }
            if (timer >= 1000000000) {
                System.out.println("FPS: " + drawCount);
                drawCount = 0;
                timer = 0;
            }
        }
    }

    public void update() {
        if (gameState == GameState.MAIN_MENU) {
            if (keyH.enterPressed) {
                gameState = GameState.PLAYING;
                keyH.enterPressed = false;
            }
        } else if (gameState == GameState.PLAYING) {
            player1.update();

            // Camera follows player
            cameraX = player1.x - screenWidth / 3;
            if (cameraX < 0) cameraX = 0;
            if (cameraX > worldWidth - screenWidth) cameraX = worldWidth - screenWidth;

            // Game Over check
            if (player1.hearts <= 0) {
                gameState = GameState.GAME_OVER;
            }

        } else if (gameState == GameState.GAME_OVER) {
            if (keyH.enterPressed) {
                restartGame();
                keyH.enterPressed = false;
            }
        }
    }

    public void restartGame() {
        player1 = new player(this, keyH);
        cameraX = 0;
        gameState = GameState.PLAYING;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        if (gameState == GameState.MAIN_MENU) {
            drawMainMenu(g2);

        } else if (gameState == GameState.PLAYING) {
            drawGame(g2);

        } else if (gameState == GameState.GAME_OVER) {
            drawGame(g2);
            drawGameOver(g2);
        }

        g2.dispose();
    }

    public void drawGame(Graphics2D g2) {
        // Draw sky background
        g2.setColor(new Color(135, 206, 235));
        g2.fillRect(0, 0, screenWidth, screenHeight);

        // Draw ground tiles across world
        int floorY = screenHeight - floorHeight;
        for (int tx = 0; tx < worldWidth; tx += tileSize) {
            if (groundTile != null) {
                g2.drawImage(groundTile, tx - cameraX, floorY, tileSize, floorHeight, null);
            } else {
                // Placeholder ground (sandy color)
                g2.setColor(new Color(194, 154, 94));
                g2.fillRect(tx - cameraX, floorY, tileSize, floorHeight);
                g2.setColor(new Color(160, 120, 60));
                g2.drawRect(tx - cameraX, floorY, tileSize, floorHeight);
            }
        }

        // Draw player
        player1.draw(g2, cameraX);

        // Draw HUD
        drawHearts(g2);
    }

    public void drawHearts(Graphics2D g2) {
        for (int i = 0; i < player1.maxHearts; i++) {
            if (i < player1.hearts) {
                g2.setColor(Color.RED);
            } else {
                g2.setColor(Color.DARK_GRAY);
            }
            g2.fillOval(10 + (i * 36), 10, 28, 28);
        }
    }

    public void drawMainMenu(Graphics2D g2) {
        g2.setColor(new Color(20, 80, 160));
        g2.fillRect(0, 0, screenWidth, screenHeight);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 52));
        g2.drawString("Darwin's Journey", 130, 200);

        g2.setColor(new Color(255, 220, 50));
        g2.setFont(new Font("Arial", Font.PLAIN, 26));
        g2.drawString("Adventure awaits!", 270, 260);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.PLAIN, 22));
        g2.drawString("Press ENTER to Start", 255, 360);

        g2.setFont(new Font("Arial", Font.PLAIN, 16));
        g2.setColor(new Color(180, 220, 255));
        g2.drawString("A = Left   D = Right   W / SPACE = Jump", 215, 430);
    }

    public void drawGameOver(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 180));
        g2.fillRect(0, 0, screenWidth, screenHeight);

        g2.setColor(Color.RED);
        g2.setFont(new Font("Arial", Font.BOLD, 64));
        g2.drawString("GAME OVER", 175, 250);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.PLAIN, 24));
        g2.drawString("Press ENTER to Retry", 240, 340);
    }
}
