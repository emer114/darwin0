package main;

public enum GameState {
    MAIN_MENU,
    PLAYING,
    GAME_OVER,
    LEVEL_CLEAR
}
