package darwin1;

public class entity {
    public int x, y;
    public int width, height;
    public int speed;
}
