package darwin1;

import main.GamePanel;
import main.KeyHandler;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class player extends entity {

    GamePanel gp;
    KeyHandler keyH;

    // Physics
    public float velocityY = 0;
    public float gravity   = 0.5f;
    public float jumpForce = -12f;
    public boolean isOnGround = false;

    // Health
    public int maxHearts = 3;
    public int hearts    = 3;

    // Direction
    public boolean facingRight = true;

    // Sprite (will be loaded once partner finishes)
    BufferedImage sprite = null;

    public player(GamePanel gp, KeyHandler keyH) {
        this.gp   = gp;
        this.keyH = keyH;

        width  = 32;
        height = 32;
        speed  = 4;

        // Start on top of the floor
        x = 100;
        y = gp.screenHeight - gp.floorHeight - height;

        // Try loading sprite (if file exists already)
        try {
            sprite = ImageIO.read(getClass().getResourceAsStream("/res/player/darwin.png"));
        } catch (Exception e) {
            sprite = null; // no sprite yet, use colored box
        }
    }

    public void update() {

        // Horizontal movement
        if (keyH.leftPressed) {
            x -= speed;
            facingRight = false;
        }
        if (keyH.rightPressed) {
            x += speed;
            facingRight = true;
        }

        // Jump
        if (keyH.jumpPressed && isOnGround) {
            velocityY = jumpForce;
            isOnGround = false;
        }

        // Gravity
        velocityY += gravity;
        y += (int) velocityY;

        // Floor collision
        int floorY = gp.screenHeight - gp.floorHeight - height;
        if (y >= floorY) {
            y = floorY;
            velocityY = 0;
            isOnGround = true;
        }

        // Left boundary
        if (x < 0) x = 0;
    }

    public void draw(Graphics2D g2, int cameraX) {
        int drawX = x - cameraX;

        if (sprite != null) {
            // Draw actual sprite when available
            if (!facingRight) {
                // Flip horizontally
                g2.drawImage(sprite, drawX + width, y, -width, height, null);
            } else {
                g2.drawImage(sprite, drawX, y, width, height, null);
            }
        } else {
            // Placeholder cube (orange like Darwin)
            g2.setColor(new Color(255, 140, 0));
            g2.fillRect(drawX, y, width, height);

            // Eyes
            g2.setColor(Color.WHITE);
            if (facingRight) {
                g2.fillOval(drawX + 18, y + 8,  8, 8);
                g2.setColor(Color.BLACK);
                g2.fillOval(drawX + 20, y + 10, 4, 4);
            } else {
                g2.fillOval(drawX + 6,  y + 8,  8, 8);
                g2.setColor(Color.BLACK);
                g2.fillOval(drawX + 8,  y + 10, 4, 4);
            }
        }
    }
}
